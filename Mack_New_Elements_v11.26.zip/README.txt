MACK_NEW_ELEMENTS v11.26
========================

A Lua custom-element mod for The Powder Toy (TPT).

STATUS
------
Still in development. This package contains:
- 99 custom element definitions
- 1 custom tool (Squeezer)
- 100 additions in total

FILES
-----
- Mack_New_Elements_v11.26.lua
- README.txt

WHAT IS INCLUDED
----------------
The mod includes custom powders, solids, liquids, gases, biological materials,
fuels, food materials, and other science-themed elements.

The v11.26 upgrade reviews the full 99-element list and expands the programmed
behaviours where the available elements support a sensible game interaction.

REACTION AND BEHAVIOUR SYSTEMS
------------------------------
1. Water and phase changes
   - Custom WATR and DSWR can freeze into ICE and boil into VAPR.
   - VAPR can condense back into custom WATR.
   - SLTW has a simplified lower freezing point and boils into VAPR.
   - Temperature values are game approximations, not a full thermodynamics model.

2. Mixing and material changes
   - SALT with WATR or DSWR forms SLTW.
   - AMMO gas touching WATR forms the custom AMMS ammonia-solution representation.
   - SOIL touching WATR becomes MUD.
   - FRSR fertiliser touching SOIL forms FRSL fertilised soil.
   - FRSL touching WATR becomes MUD.
   - PJUI and FRJU are diluted by WATR into DPLJ and DFJU.

3. Acid and carbonate demonstrations
   - BICA or CALC can react with ACID, CITR, or ACET.
   - These simplified contact reactions produce CO2G particles.
   - The reaction is an educational visual approximation, not a complete chemical equation.

4. Biological decay
   - FUGI and ROT can convert selected food and organic materials into ROT.
   - The affected materials include wheat, grass, corn, carrot, milk, fruit,
     ALPR plant material, eggs, wool, and the two juice types.

5. Corrosion and oxidation
   - IRON and STEL can become RUML when custom water and oxygen are nearby.
   - CARB and SULF can oxidise when strongly heated with custom oxygen nearby.

6. Heat and fuel effects
   - Heated H2O2 changes into custom WATR and releases an OXYG particle.
   - Configured custom fuels change into native FIRE when touching native FIRE
     or SPRK. KRSE jet fuel is included.
   - EXPL is a fictional game element that changes into native BANG when
     touching native FIRE or SPRK. This is a game-only effect.

7. Farming and animals
   - CRSD can grow into CRSP when soil or fertilised soil and water are nearby.
   - CRSP can grow into CRSK after continued suitable updates.
   - Cows and sheep eat adjacent configured plant foods; chickens eat adjacent
     grain, seed, and fertiliser materials.
   - Cows produce MILK, sheep produce WOOL, and chickens produce EGG.
   - Animals wander horizontally and remain single-particle elements.

8. Liquid surface bubbles
   - WATR, DSWR, DSEL, OIL, and COIL have the configured visual bubble effect.

9. Squeezer tool
   - FRUT can be squeezed into FRJU.
   - CRSK, ALPR, and WHEA can be squeezed into PJUI.
   - COW and SHEP can produce MILK when used with the tool.
   - MUD can be squeezed into WATR.

IMPORTANT REACTION COVERAGE NOTE
--------------------------------
All 99 element entries have been reviewed, but not every element should react
with every other element. Some materials are stable or do not have a suitable
custom product in this mod. Noble gases and several metals, for example, are
intentionally not given arbitrary contact reactions. Elements without a
programmed custom reaction still use their configured Powder Toy physics.

This is a simplified particle simulation. It is not a complete chemistry,
biology, or thermodynamics simulator. Do not use the in-game effects as
instructions for handling real chemicals or materials.

INSTALLATION
------------
1. Download the ZIP file.
2. Extract the ZIP file.
3. Open the extracted folder.
4. Copy Mack_New_Elements_v11.26.lua into The Powder Toy's scripts folder.
5. Start The Powder Toy.
6. Open Script Manager.
7. Find Mack_New_Elements and enable it.
8. Check the game console for the load message.

The Squeezer requires a Powder Toy build that provides the Lua tools API.
If that API is unavailable in your build, the other script features may load
but the Squeezer will not be registered; the console will display a warning.

CREDITS
-------
- Mackeria — Designer, Founder, and Project Developer
- ChatGPT — Coding Assistant

SHARING
-------
This project is posted on GitHub and the official Powder Toy forum.
Please ask the developer for permission before reposting it on other websites
or platforms. Do not claim to be the original developer.

VERSION
-------
MACK_NEW_ELEMENTS v11.26
