Readme of the LUA SCRIPT MOD:

Details about this lua script mod:
Name:Mack_New_Elements_v11.26
Stage:Newest/latest
STAGE:In development/ready or not ready

People or bots who are included in making this lua script mod/CREDITS:
1.ChatGPT(1stCoder/assistant)
2.Claude(2ndCoder/assistant)
3.Mackeria(Designer/Developer)

1)(AI)
2)(AI)
3)(TPT USER)

Details/more info:
1.Added reaction systems
2.Added 86 elements(also included tools)
3.Tools=1
4.Elements=85

Sections you can find those elements:
1.Radioactive section
2.Special section
3.Solid section
4.Gas section
5.Powder section
6.Explosive section

Target version of TPT(mod targeted for [version]of TPT):  TPT v100.0(newest version of TPT)

Thanks to this people/bots:
1.ChatGPT
2.Claude
3.Mackeria

In total of people/bots:
AIs=2
Users=1

=====END OF README=====