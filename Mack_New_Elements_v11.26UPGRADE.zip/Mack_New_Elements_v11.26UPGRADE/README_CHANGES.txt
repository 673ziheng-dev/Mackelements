Mack_New_Elements v11.26 UPGRADE
================================
Install: copy Mack_New_Elements_v11.26.lua into your Powder Toy folder (autorun.lua
or the scripts folder, depending on how you load scripts).

REACTIONS INCLUDED (all real-life based, simplified)
- SALT + WATR/DSWR/SLTW -> SLTW (dissolving)
- WATR + AMMO -> AMMS ; AMMO + WATR -> AMMS
- PJUI/FRJU + WATR -> DPLJ/DFJU (dilution)
- SOIL + FRSR -> FRSL (fertilised soil)
- SOIL/FRSL + WATR -> MUD (not when a seed/sprout is beside it)
- BICA + ACID/ACET -> CO2G (spent acid -> WATR); BICA + CITR -> CO2G only with water nearby
- ACID + IRON/STEL/ZINC/ALUM -> HYDR (slow)
- CUSU + IRON/STEL/ZINC (with water nearby) -> COPR (copper displacement)
- IRON/STEL + water + OXYG -> RUML (rusting, slow)
- CARB (hot, 500 C) + OXYG -> CO2G ; SULF (hot, 250 C) + OXYG -> SUOX
- H2O2 heated to 150 C -> WATR + OXYG
- Fuels + fire/spark -> fire: OIL DSEL DESL PETR VOIL COIL BITH ETHL KRSE HYDR METH ETHA
  PROP BUTA COMO H2SG (EXPL is the fictional arcade explosive, kept as requested)
- Hot COIL/VOIL (>100 C) + water -> steam (sizzle)
- FUGI/ROT slowly turn WHEA CRSK CORN CROT MILK FRUT ALPR EGG WOOL PJUI FRJU DPLJ DFJU into ROT
- Water: freezes 0 C, boils 100 C; SLTW freezes -5 C; ICE melts; VAPR condenses
- LINI boils into NITR, LIOX boils into OXYG (they start very cold)
- Seed growth: CRSD + soil/fertilised soil + water -> CRSP -> CRSK
- Animals eat, wander, and produce MILK / WOOL / EGG

NO REACTIONS (none in real life, or element identity unspecified)
HELI ARGO NEON KRYO XENO (noble gases), N2OG, OZON, CHLO, NODI, FORM, UNOL, CALC, SOCA,
POCL, MGOX, IROX, GLUC, SUCR, SOAP, MERC, BROM, GLYC, GALL, PHOS, IODI, SILI, TITN,
BRSS, TIN, BRZE, RUML, MUD, ICE/VAPR (phase change only).

NOT ADDED because no product element exists
- Sugar/potassium chloride dissolving, copper sulfate dissolving, gallium freezing,
  ethanol evaporating, metal-oxide acid neutralisation, milk curdling.
  (Add a solution/solid element first and a rule can be added.)

FIXES FROM v11.26
- Temperatures were treated as Celsius; Powder Toy uses Kelvin. All thresholds converted.
  (The H2O2 150-degree check would previously have triggered at once.)
- Added the missing helper functions the script called but never defined.
- Each element now has one combined Update; earlier callbacks overwrote each other.
- Soil no longer becomes mud before seeds can germinate.
- Fungus/rot no longer turn themselves into ROT; only the food changes.
- Animals no longer return "removed" every time they eat.
- Non-metal solids no longer inherit the metal template's melt-to-lava transition.
- CALC acid reactions removed (formula unspecified). The unused bubble effect was removed.

KNOWN LIMITS
- Not run-tested in Powder Toy (no Lua runtime was available when this was built).
- The Squeezer needs a build with tools.allocate/tools.property; otherwise it prints a
  message and is skipped.
