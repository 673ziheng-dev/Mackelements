-- ============================================================
-- Mack_New_Elements v11.26 UPGRADE
-- Custom element definitions, descriptions, reactions, feeding, and a Squeezer tool.
--
-- UPGRADE NOTES
--  * Only reactions that really happen in real life are included (simplified for the game).
--    Elements with no real reaction (or no product element to react into) have NO reaction.
--  * All temperatures are converted to Kelvin, which is what Powder Toy uses internally.
--  * Missing helper functions are now defined (neighbour scanning, water checks).
--  * Each element gets ONE combined Update function, so behaviours no longer overwrite each other.
--  * Seeds can now actually germinate (soil next to a seed no longer turns to mud first).
--  * Animals no longer report themselves as "removed" every time they eat.
-- ============================================================

local GROUP = "MACKELEMENTS"

-- Powder Toy stores temperatures in Kelvin.
local function K(celsius) return celsius + 273.15 end
local ROOM = K(22)

local sections = {
    powder = elem.SC_POWDERS,
    liquid = elem.SC_LIQUID,
    solid = elem.SC_SOLIDS,
    gas = elem.SC_GAS,
    special = elem.SC_SPECIAL,
    tool = elem.SC_TOOL
}

local templates = {
    powder = elements.DEFAULT_PT_DUST,
    liquid = elements.DEFAULT_PT_WATR,
    solid = elements.DEFAULT_PT_METL,
    gas = elements.DEFAULT_PT_GAS,
    special = elements.DEFAULT_PT_DUST,
    tool = elements.DEFAULT_PT_DUST
}

-- Each entry is: {ID, ID, colour, category, description}
-- The first and second fields intentionally match, as requested.
local data = {
    {"SULF", "SULF", 0xE6D64A, "powder", "Sulfur (S): a yellow nonmetal found in minerals and living organisms. In Mackelements, it burns into SUOX gas when it is hot (about 250 °C) and touches oxygen."},
    {"CARB", "CARB", 0x333333, "solid", "Carbon (C): an element found in charcoal, graphite, diamonds, and all known living things. In Mackelements, very hot carbon (about 500 °C) touching oxygen burns into carbon dioxide."},
    {"SALT", "SALT", 0xFFFFFF, "powder", "Table salt (sodium chloride, NaCl): a crystalline compound used to season and preserve food. In Mackelements, it dissolves into salt water (SLTW) when it touches WATR, DSWR, or SLTW."},
    {"IROX", "IROX", 0xB84A25, "powder", "Iron oxide: a family of compounds made from iron and oxygen, often responsible for red or brown colours in rust and minerals. Iron oxides are used in pigments and materials; this entry is a reddish powder representation."},
    {"SUCR", "SUCR", 0xF5F0D8, "powder", "Sucrose: common table sugar, a carbohydrate found naturally in many plants. It sweetens foods and dissolves in water in real life; this custom powder has no dissolving behaviour because there is no sugar-water element."},
    {"BICA", "BICA", 0xE8E8E8, "powder", "Sodium bicarbonate (NaHCO₃), often called baking soda. In Mackelements, it fizzes into carbon dioxide gas when it touches ACID or ACET, or CITR when water is also nearby."},
    {"WATR", "WATR", 0x204DFF, "liquid", "Water (H₂O): a liquid essential to life and widely used for cleaning, transport, and cooling. In Mackelements, custom water freezes into ICE near 0 °C and boils into VAPR near 100 °C."},
    {"ETHL", "ETHL", 0xB8D9FF, "liquid", "Ethanol (C₂H₅OH): an alcohol used in some sanitising products, laboratory work, and fuels. It is flammable: in Mackelements it ignites when it touches fire or a spark."},
    {"MERC", "MERC", 0xB8BEC7, "liquid", "Mercury (Hg): a dense, silvery metal that is liquid at ordinary room temperature. Mercury is toxic and requires specialised handling; this custom element is only a visual simulation and should not be confused with real mercury."},
    {"GLYC", "GLYC", 0xD9E8F2, "liquid", "Glycerol (glycerin): a colourless, viscous liquid used in soaps, cosmetics, medicines, and food products. Its thickness makes it useful for comparing liquid flow; the custom element does not guarantee realistic viscosity."},
    {"H2O2", "H2O2", 0xD8F0FF, "liquid", "Hydrogen peroxide (H₂O₂): a chemical used in some cleaning and bleaching products. In Mackelements, strong heating (150 °C in this simplified game model) changes it into custom water and releases an oxygen particle."},
    {"VOIL", "VOIL", 0xB8A23A, "liquid", "Vegetable oil: oil obtained from plants and commonly used in cooking. It is flammable when hot enough: it ignites on fire or a spark, and hot oil makes nearby water flash into steam."},
    {"OXYG", "OXYG", 0x70B9FF, "gas", "Oxygen (O₂): a colourless gas that organisms need for aerobic respiration and that supports combustion. In Mackelements, it is needed for iron/steel rusting and for burning CARB and SULF. It condenses to nothing on its own; LIOX boils into it."},
    {"NITR", "NITR", 0x9AB8E8, "gas", "Nitrogen (N₂): a colourless gas that makes up about 78% of Earth’s atmosphere. It is relatively unreactive under ordinary conditions; in Mackelements, LINI boils into this gas when it warms up."},
    {"CO2G", "CO2G", 0xA9A9A9, "gas", "Carbon dioxide (CO₂): a colourless gas released by respiration and many combustion processes. In Mackelements, it is the product of baking-soda fizzing and of burning hot carbon."},
    {"HELI", "HELI", 0xFFF0B5, "gas", "Helium (He): a very light, nonflammable noble gas used in scientific equipment, leak detection, and some balloons. It is chemically unreactive, so this custom gas has no reactions."},
    {"ARGO", "ARGO", 0xC4C9E8, "gas", "Argon (Ar): a colourless noble gas that forms just under 1% of Earth’s atmosphere. It is chemically unreactive, so this custom gas has no reactions."},
    {"NEON", "NEON", 0xFF8B55, "gas", "Neon (Ne): a noble gas that can glow reddish-orange in a suitable electrical discharge tube. It is chemically unreactive, so this custom gas has no reactions."},
    {"VAPR", "VAPR", 0xD8E8F5, "gas", "Water vapour: water in its gaseous state. In Mackelements, custom VAPR condenses into WATR when cooled below about 100 °C; it is also the boiling product of the custom water family."},
    {"COPR", "COPR", 0xC96B3B, "solid", "Copper (Cu): a reddish metal that conducts electricity and heat very well. In Mackelements, it is produced when iron, steel, or zinc touches copper sulfate (CUSU) and water."},
    {"IRON", "IRON", 0x777777, "solid", "Iron (Fe): a strong, magnetic metal used in tools, structures, and steelmaking. In Mackelements, iron slowly changes into RUML rusted metal when water and oxygen are both nearby; strong acid also attacks it and releases hydrogen."},
    {"ALUM", "ALUM", 0xD6D6D6, "solid", "Aluminium (Al): a lightweight metal that forms a thin protective oxide layer in air. In Mackelements, it does not rust, but strong acid attacks it and releases hydrogen."},
    {"ZINC", "ZINC", 0xB9C1C8, "solid", "Zinc (Zn): a bluish-silver metal commonly used to protect steel from corrosion by galvanising. In Mackelements, it reacts with strong acid to release hydrogen and displaces copper from copper sulfate and water."},
    {"SILI", "SILI", 0x777C85, "solid", "Silicon (Si): a metalloid found in sand and many minerals as compounds such as silica. Purified silicon is important in computer chips and solar cells; this custom solid is a simple material representation, not a semiconductor model."},
    {"CALC", "CALC", 0xF0EEE5, "powder", "Calcium compound: this entry represents a calcium-containing mineral material, but its exact chemical formula is not specified by the ID, so it has no reactions. Calcium compounds occur in bones, shells, limestone, and cement."},
    {"SOCA", "SOCA", 0xE5E5E5, "powder", "Sodium compound: the exact substance is not specified by this custom ID, so it has no reactions. Sodium compounds have diverse uses in food, manufacturing, and household products."},
    {"POCL", "POCL", 0xF5F0E5, "powder", "Potassium chloride (KCl): a salt-like compound used in fertilisers and some other industrial and laboratory applications. It dissolves in water in real life; this custom powder does not, because there is no matching solution element."},
    {"MGOX", "MGOX", 0xFFFFFF, "powder", "Magnesium oxide (MgO): a white solid used in refractory materials and some industrial applications because it tolerates high temperatures. This custom powder represents the compound and has no reactions."},
    {"GLUC", "GLUC", 0xE8D8A0, "powder", "Glucose (C₆H₁₂O₆): a simple sugar used by cells as an important energy source. It occurs in fruits and is used in food and scientific applications; this custom powder is for mixture experiments, not metabolism simulation."},
    {"CITR", "CITR", 0xF0E6B0, "powder", "Citric acid: a weak organic acid found naturally in citrus fruits. In Mackelements, it fizzes with baking soda (BICA) into carbon dioxide, but only when water is also nearby, as in real life."},
    {"ICE", "ICE", 0x9BE5FF, "solid", "Ice: solid water formed when custom WATR or DSWR freezes. In Mackelements, ICE changes back into WATR when warmed above its simplified melting point near 0 °C."},
    {"PHOS", "PHOS", 0xE6C45A, "solid", "Phosphorus (P): a reactive nonmetal essential to living organisms and found in compounds such as phosphates. Different forms have different properties; this custom solid is a simplified representation and does not model phosphorus chemistry."},
    {"IODI", "IODI", 0x705080, "solid", "Iodine (I₂): a halogen that is a dark, lustrous solid at room temperature and can form violet vapour when heated. Iodine compounds are used in several scientific and medical contexts; this custom solid does not simulate sublimation."},
    {"CUSU", "CUSU", 0x2878D0, "powder", "Copper sulfate: a copper compound often encountered as blue crystals in its hydrated form. It can be harmful if mishandled. In Mackelements, with water nearby, iron, steel, or zinc touching it turns it into copper (COPR)."},
    {"ACET", "ACET", 0xD8E8F5, "liquid", "Acetic acid (CH₃COOH): the acid that gives vinegar its sour taste and smell. In Mackelements, it fizzes with baking soda (BICA), releasing carbon dioxide; the spent acid becomes water."},
    {"ACID", "ACID", 0xE0E8F0, "liquid", "Generic strong acid: this entry does not identify a particular chemical formula. In Mackelements, it fizzes with baking soda (BICA), and slowly attacks iron, steel, zinc, and aluminium, releasing hydrogen gas."},
    {"AMMS", "AMMS", 0xBFE8D8, "liquid", "Ammonia solution: ammonia dissolved in water. In Mackelements, AMMO gas and custom WATR both change into AMMS when they touch; this is a simplified mixing effect."},
    {"SLTW", "SLTW", 0x65A9E8, "liquid", "Salt water: a mixture of water and dissolved salt. Mackelements forms it when SALT touches WATR or DSWR; it has a simplified freezing point near −5 °C and boils into VAPR near 100 °C."},
    {"SOAP", "SOAP", 0xA8E8F0, "liquid", "Soap: a cleaning substance whose molecules help water remove oils and dirt. Soaps are used in washing and cleaning; this custom liquid has no reactions."},
    {"MILK", "MILK", 0xFFF8E8, "liquid", "Milk: a nutrient-containing liquid mixture of water, fats, proteins, sugars, and minerals produced by mammals. In Mackelements, fungus (FUGI) or rot (ROT) will spoil it into ROT."},
    {"BROM", "BROM", 0x9C432B, "liquid", "Bromine (Br₂): a dense, reddish-brown halogen that is liquid at ordinary room temperature and gives off hazardous vapour. It requires specialised controls in real life; this custom element is only a visual educational representation."},
    {"GALL", "GALL", 0xD0D0D8, "liquid", "Gallium (Ga): a silvery metal that melts at about 30 °C, close to warm room temperature. It is used in some semiconductor materials; this custom liquid uses a liquid template and does not solidify when cooled."},
    {"LINI", "LINI", 0xBDEBFF, "liquid", "Liquid nitrogen: nitrogen cooled below its boiling point, about −196 °C. It can cause severe cold injuries. In Mackelements, it starts extremely cold and boils into NITR gas as it warms above about −196 °C."},
    {"LIOX", "LIOX", 0x72B9FF, "liquid", "Liquid oxygen: oxygen cooled below its boiling point, about −183 °C. It is a powerful oxidiser. In Mackelements, it starts extremely cold and boils into OXYG gas as it warms above about −183 °C."},
    {"HYDR", "HYDR", 0xE5F5FF, "gas", "Hydrogen (H₂): the lightest element and a colourless gas. It is highly flammable: in Mackelements it ignites when it touches fire or a spark. It is also released when strong acid attacks some metals."},
    {"CHLO", "CHLO", 0xB8D64B, "gas", "Chlorine (Cl₂): a yellow-green halogen gas used in controlled water treatment and chemical manufacturing. Chlorine gas is toxic and irritating, so this custom element is an educational representation only and has no reactions."},
    {"AMMO", "AMMO", 0xD9F0D8, "gas", "Ammonia (NH₃): a colourless gas used in fertiliser production and refrigeration systems. In Mackelements, AMMO changes into AMMS when it touches custom WATR; this is a simplified game interaction."},
    {"METH", "METH", 0xC4C4C4, "gas", "Methane (CH₄): the simplest hydrocarbon and a major component of natural gas. It is flammable: in Mackelements it ignites when it touches fire or a spark."},
    {"COMO", "COMO", 0xA5A5A5, "gas", "Carbon monoxide (CO): a colourless, odourless toxic gas that can form during incomplete combustion. It is flammable: in Mackelements it ignites when it touches fire or a spark."},
    {"N2OG", "N2OG", 0xC8D5E8, "gas", "Nitrous oxide (N₂O): a colourless gas used in some medical, food-production, and industrial contexts under appropriate controls. This custom gas has no reactions."},
    {"SUOX", "SUOX", 0xE5D9A0, "gas", "Sulfur oxide gas: a generic label for sulfur oxides, such as sulfur dioxide. In Mackelements, it is the product of burning hot sulfur in oxygen."},
    {"OZON", "OZON", 0x8B85D8, "gas", "Ozone (O₃): a form of oxygen. High in the atmosphere it helps absorb ultraviolet radiation, while near the ground it is an air pollutant; this custom gas has no reactions."},
    {"KRYO", "KRYO", 0xD0D0E8, "gas", "Krypton (Kr): a colourless noble gas present in trace amounts in air. It is chemically unreactive, so this custom gas has no reactions."},
    {"XENO", "XENO", 0xA8A8D8, "gas", "Xenon (Xe): a heavy noble gas found in trace amounts in the atmosphere. It is chemically unreactive under these conditions, so this custom gas has no reactions."},
    {"H2SG", "H2SG", 0xB8C477, "gas", "Hydrogen sulfide (H₂S): a colourless, highly toxic gas known for a rotten-egg smell at low concentrations. It is flammable: in Mackelements it ignites when it touches fire or a spark."},
    {"ETHA", "ETHA", 0xC9D9E8, "gas", "Ethane (C₂H₆): a simple hydrocarbon found in natural gas. It is flammable: in Mackelements it ignites when it touches fire or a spark."},
    {"PROP", "PROP", 0xB8C8D8, "gas", "Propane (C₃H₈): a hydrocarbon commonly used as a fuel for heating and cooking. It is flammable: in Mackelements it ignites when it touches fire or a spark."},
    {"BUTA", "BUTA", 0xA8B8C8, "gas", "Butane (C₄H₁₀): a flammable hydrocarbon used in some fuel applications and portable appliances. In Mackelements, it ignites when it touches fire or a spark."},
    {"NODI", "NODI", 0xB86A42, "gas", "Custom material NODI: the original project ID does not specify a reliable chemical name, so it has no reactions. It is a gas-template element."},
    {"FORM", "FORM", 0xD8E8E8, "gas", "Custom material FORM: the original project ID does not establish a precise chemical identity, so it has no reactions. It uses the gas template."},
    {"DSWR", "DSWR", 0x173DAD, "liquid", "Distilled water: water with dissolved minerals removed. It uses the water template with a custom colour, freezes into ICE near 0 °C, boils into VAPR near 100 °C, and turns into salt water when SALT touches it."},
    {"DSEL", "DSEL", 0xE8D16B, "liquid", "Diesel fuel: a petroleum-derived fuel used in many compression-ignition engines. In Mackelements, it ignites when it touches fire or a spark."},
    {"DESL", "DESL", 0xD8BD5A, "liquid", "Diesel-style game fuel alias added for compatibility with the DESL ID. It ignites when it touches fire or a spark."},
    {"UNOL", "UNOL", 0x171717, "liquid", "Custom liquid UNOL: the ID does not identify a definite real-world substance, so it has no reactions. It is based on the water template with a dark colour."},
    {"KRSE", "KRSE", 0x4D88CC, "liquid", "Jet fuel: a custom aviation-fuel liquid. It changes into a game flame when touching native fire or spark; this is not a real fuel specification."},
    {"OIL", "OIL", 0xA77B45, "liquid", "Oil: a broad term for liquids that do not mix readily with water. In Mackelements, it ignites when it touches fire or a spark."},
    {"COIL", "COIL", 0xD9A800, "liquid", "Cooking oil: it helps you cook foods. When hot (above 100 °C) it sizzles, flashing nearby water into steam, and it ignites on fire or a spark."},
    {"COW", "COW", 0x222222, "special", "Cow: a farm mammal raised for milk, meat, and other agricultural purposes. In Mackelements, the custom cow can eat adjacent configured food, wander horizontally, and produce MILK; it is still a single particle."},
    {"SHEP", "SHEP", 0xF5F5F5, "special", "Sheep: a domesticated mammal raised for wool, meat, and milk in some breeds. In Mackelements, the sheep can eat adjacent plant foods, wander horizontally, and produce WOOL; it remains a single particle."},
    {"CHKN", "CHKN", 0xF2D23B, "special", "Chicken: a domesticated bird raised for eggs and meat. In Mackelements, the chicken can eat adjacent grain or seed-like food, wander horizontally, and lay EGG particles; it remains a single particle."},
    {"WHEA", "WHEA", 0x9BD66B, "powder", "Wheat: a cereal grain used to make flour, bread, pasta, and other foods, and also used as livestock feed. In Mackelements, it is food for cows, sheep, and chickens, and it rots when fungus or rot touches it."},
    {"CRSK", "CRSK", 0xB8D98B, "powder", "Grass: the grown form of grass sprouts (CRSP). It is food for cows and sheep, can be squeezed into plant juice, and rots when fungus or rot touches it."},
    {"CROT", "CROT", 0xF08024, "solid", "Carrot: an edible root vegetable rich in beta-carotene, which the body can convert to vitamin A. In Mackelements, it is food for cows and sheep, and it rots when fungus or rot touches it."},
    {"ALPR", "ALPR", 0xC8C8C8, "powder", "Custom plant-like material ALPR: its exact real-world identity is unspecified. It can be processed into PJUI by the Squeezer, eaten by cows and sheep, and it rots when fungus or rot touches it."},
    {"CRSD", "CRSD", 0xE8D66A, "powder", "Grass seed: a seed-like plant material. It is food for cows, sheep, and chickens. When adjacent to both soil (or fertilised soil) and water, it grows into a CRSP sprout, which can later become CRSK grass."},
    {"CORN", "CORN", 0xD9B928, "solid", "Corn (maize): a cereal crop used as food for people and animals. In Mackelements, it is food for cows, sheep, and chickens, and it rots when fungus or rot touches it."},
    {"PETR", "PETR", 0xE8B52D, "liquid", "Petroleum: a naturally occurring mixture of hydrocarbons extracted from underground reservoirs. In Mackelements, it ignites when it touches fire or a spark."},
    {"STEL", "STEL", 0x888D93, "solid", "Steel: an alloy made mainly from iron and carbon. In Mackelements, steel slowly changes into RUML rusted metal when water and oxygen are both nearby; strong acid attacks it and releases hydrogen, and it displaces copper from CUSU with water."},
    {"TITN", "TITN", 0xAEB4BA, "solid", "Titanium (Ti): a strong, relatively lightweight metal with good corrosion resistance, so this custom solid has no reactions."},
    {"ROT", "ROT", 0xD97935, "special", "Rot: a custom material representing decay. In Mackelements, it spreads slowly into nearby organic materials such as food, milk, eggs, wool, and juices."},
    {"RUML", "RUML", 0xB94B2C, "special", "Rusted metal: a custom material representing iron or steel affected by corrosion. RUML does not spread rust to other metals."},
    {"FUGI", "FUGI", 0xB8D6A0, "special", "Fungus: a custom biological material inspired by fungi, which break down organic matter. In Mackelements, it slowly turns nearby organic materials into ROT."},
    {"BITH", "BITH", 0xD6D6D6, "solid", "Bitumen: a dark, sticky petroleum-derived material used in asphalt and waterproofing. In Mackelements, it ignites when it touches fire or a spark."},
    {"BRSS", "BRSS", 0xE6C229, "solid", "Brass: an alloy made mainly from copper and zinc. It is used in fittings, instruments, decorative objects, and hardware; this custom solid has no reactions."},
    {"TIN", "TIN", 0xDADDE0, "solid", "Tin (Sn): a soft, silvery metal that resists corrosion in many ordinary environments. This custom solid has no reactions."},
    {"BRZE", "BRZE", 0xC77A4A, "solid", "Bronze: a family of copper-based alloys, traditionally often containing tin. This custom solid has no reactions."},
    {"EGG", "EGG", 0xF4ECDD, "solid", "Egg: a reproductive structure laid by birds and some other animals. In Mackelements, eggs are laid by chickens and rot when fungus or rot touches them; hatching is not implemented."},
    {"FRUT", "FRUT", 0xD95B43, "solid", "Fruit: a generic juicy fruit material. Use the Squeezer tool on FRUT to produce FRJU fruit juice; the fruit is consumed when squeezing succeeds. It rots when fungus or rot touches it."},
    {"PJUI", "PJUI", 0x4FAD54, "liquid", "Plant Juice: a green liquid extracted by the Squeezer from CRSK grass, ALPR, and WHEA wheat. It dilutes into DPLJ when it touches water, and rots when fungus or rot touches it."},
    {"FRJU", "FRJU", 0xF08A36, "liquid", "Fruit Juice: an orange-coloured liquid produced when the Squeezer processes FRUT. It dilutes into DFJU when it touches water, and rots when fungus or rot touches it."},
    {"CRSP", "CRSP", 0x77C95B, "powder", "Grass sprout: an early growth stage of a grass plant. In Mackelements, a CRSD seed becomes a sprout when soil and water are nearby; with continued suitable conditions, the sprout grows into CRSK grass."},
    {"WOOL", "WOOL", 0xF0EEE8, "powder", "Wool: a soft fibre produced by sheep. In Mackelements, sheep periodically produce wool when there is room nearby, and it rots when fungus or rot touches it."},
    {"DPLJ", "DPLJ", 0x83C77D, "liquid", "Diluted Plant Juice: a lighter green liquid made when Plant Juice touches custom Water. It rots when fungus or rot touches it."},
    {"DFJU", "DFJU", 0xF4B36C, "liquid", "Diluted Fruit Juice: a lighter orange liquid made when Fruit Juice touches custom Water. It rots when fungus or rot touches it."},
    {"SOIL", "SOIL", 0x8B5A2B, "powder", "Soil: a mixture of mineral particles, organic matter, water, air, and living organisms that supports plant growth. In Mackelements, soil turns into MUD when it touches custom water, unless a seed or sprout is next to it; it mixes with FRSR to form FRSL."},
    {"FRSR", "FRSR", 0xC4A484, "powder", "Fertiliser: a custom nutrient material with unspecified composition. In Mackelements, chickens can eat it, and it combines with SOIL to form FRSL fertilised soil."},
    {"FRSL", "FRSL", 0x4B2E1F, "powder", "Fertilised soil: soil mixed with the custom FRSR fertiliser. In Mackelements, it supports CRSD seed sprouting and CRSP growth when water is nearby; otherwise it turns into MUD when it becomes wet."},
    {"EXPL", "EXPL", 0xE64A26, "powder", "Arcade Explosive: a fictional game-only powder that creates a brief Powder Toy burst when it touches fire or a spark. It is not a recipe or representation of a real-world explosive."},
    {"MUD", "MUD", 0xA16B45, "liquid", "Mud: wet soil mixed with water, common around rivers, wetlands, and after rain. It can be squeezed with the Squeezer tool to recover water."}
}

-- Solids that keep the metal template's high-temperature melting behaviour.
-- Every other custom solid has its inherited transitions switched off.
local metalSolids = {
    COPR = true, IRON = true, ALUM = true, ZINC = true, STEL = true,
    TITN = true, BRSS = true, TIN = true, BRZE = true, SILI = true
}

-- Register all custom elements.
local customIDs = {}
local registeredCount = 0

for _, entry in ipairs(data) do
    local name = entry[1]
    local identifier = entry[2]
    local colour = entry[3]
    local category = entry[4]
    local description = entry[5]

    local id = elements.allocate(GROUP, identifier)

    if id and id >= 0 then
        local template = elements.element(templates[category])
        elements.element(id, template)

        -- Keep custom liquids from changing into unrelated native elements.
        local disableTransitions = (category == "liquid" and identifier ~= "WATR")
            or (category == "solid" and not metalSolids[identifier])
        if disableTransitions then
            elements.property(id, "LowTemperature", -273.15)
            elements.property(id, "LowTemperatureTransition", -1)
            elements.property(id, "HighTemperature", 1000000)
            elements.property(id, "HighTemperatureTransition", -1)
        end

        -- Prevent custom gases from inheriting unwanted pressure transitions.
        if category == "gas" then
            elements.property(id, "HighPressure", 257)
            elements.property(id, "HighPressureTransition", -1)
        end
        elements.property(id, "Name", name)
        elements.property(id, "Description", description)
        elements.property(id, "Color", colour)
        elements.property(id, "MenuSection", sections[category])
        customIDs[identifier] = id
        registeredCount = registeredCount + 1
    else
        print("Mackelements: failed to register " .. identifier)
    end
end

-- ============================================================
-- HELPER FUNCTIONS
-- ============================================================
local neighbourIterator = sim.neighbours or sim.neighbors

-- Returns a set {[typeID] = true} of every particle type touching (x, y).
local function collectNeighbourTypes(x, y, selfIndex)
    local found = {}
    for p in neighbourIterator(x, y, 1, 1) do
        if p ~= nil and p >= 0 and p ~= selfIndex then
            found[sim.partProperty(p, sim.FIELD_TYPE)] = true
        end
    end
    return found
end

-- Returns only the wanted types that are touching (x, y).
local function getNeighbourTypes(x, y, wanted, selfIndex)
    local found = collectNeighbourTypes(x, y, selfIndex)
    local result = {}
    for typeID in pairs(wanted) do
        if found[typeID] then result[typeID] = true end
    end
    return result
end

local function hasNeighbourType(x, y, typeID, selfIndex)
    if not typeID then return false end
    return collectNeighbourTypes(x, y, selfIndex)[typeID] == true
end

-- Returns the index of the first neighbouring particle whose type is in typeSet.
local function findNeighbourIn(x, y, typeSet, selfIndex)
    for p in neighbourIterator(x, y, 1, 1) do
        if p ~= nil and p >= 0 and p ~= selfIndex then
            if typeSet[sim.partProperty(p, sim.FIELD_TYPE)] then return p end
        end
    end
    return nil
end

local waterTypeSet = {}
for _, identifier in ipairs({"WATR", "DSWR", "SLTW"}) do
    if customIDs[identifier] then waterTypeSet[customIDs[identifier]] = true end
end

local function hasWater(found)
    for typeID in pairs(waterTypeSet) do
        if found[typeID] then return true end
    end
    return false
end

local function hasNativeFireOrSpark(found)
    return found[elements.DEFAULT_PT_FIRE] == true or found[elements.DEFAULT_PT_SPRK] == true
end

local function findEmptyNear(x, y, maxRadius)
    for radius = 1, (maxRadius or 3) do
        for dx = -radius, radius do
            for dy = -radius, radius do
                if math.abs(dx) == radius or math.abs(dy) == radius then
                    local px, py = x + dx, y + dy
                    local p = sim.partID(px, py)
                    if p == nil or p < 0 then
                        return px, py
                    end
                end
            end
        end
    end
    return nil, nil
end

-- ============================================================
-- WATER FAMILY PHASE CHANGES (Kelvin)
-- ============================================================
local function configureWater(elementID, freezeC, iceID, vapourID)
    if not elementID then return end
    elements.property(elementID, "LowTemperature", K(freezeC))
    elements.property(elementID, "LowTemperatureTransition", iceID)
    elements.property(elementID, "HighTemperature", K(100))
    elements.property(elementID, "HighTemperatureTransition", vapourID)
end

local waterID = customIDs["WATR"]
local iceID = customIDs["ICE"]
local vapourID = customIDs["VAPR"]

if iceID and vapourID and waterID then
    configureWater(waterID, 0, iceID, vapourID)
    configureWater(customIDs["DSWR"], 0, iceID, vapourID)
    configureWater(customIDs["SLTW"], -5, iceID, vapourID)

    -- ICE melts back into normal water (0.5 degrees above freezing to avoid flicker).
    elements.property(iceID, "HighTemperature", K(0.5))
    elements.property(iceID, "HighTemperatureTransition", waterID)

    -- VAPR condenses into normal water (1 degree below boiling to avoid flicker).
    elements.property(vapourID, "LowTemperature", K(99))
    elements.property(vapourID, "LowTemperatureTransition", waterID)
end

-- CRYOGENIC LIQUIDS: real liquid nitrogen / oxygen boil into gas as they warm.
local function configureCryogen(identifier, boilK, startK, gasIdentifier)
    local id = customIDs[identifier]
    local gasID = customIDs[gasIdentifier]
    if not id or not gasID then return end
    elements.property(id, "Temperature", startK)
    elements.property(id, "HighTemperature", boilK)
    elements.property(id, "HighTemperatureTransition", gasID)
end
configureCryogen("LINI", 77.36, 70, "NITR")
configureCryogen("LIOX", 90.19, 85, "OXYG")

-- ============================================================
-- REACTION TABLE
-- Only reactions that exist in real life (simplified). A rule is:
--   {neighbour, product [, chance [, "WATER"]]}
-- The current particle changes into 'product' when 'neighbour' touches it.
-- chance (0-1) slows a reaction down; "WATER" means any custom water must also be nearby.
-- Materials with no real reaction are deliberately NOT listed.
-- ============================================================
local rotChance = 0.04

local extraReactions = {
    -- Dissolving / mixing
    SALT = {{"WATR", "SLTW"}, {"DSWR", "SLTW"}, {"SLTW", "SLTW"}},
    WATR = {{"SALT", "SLTW"}, {"PJUI", "DPLJ"}, {"FRJU", "DFJU"}, {"AMMO", "AMMS"}},
    DSWR = {{"SALT", "SLTW"}},
    AMMO = {{"WATR", "AMMS"}},
    PJUI = {{"WATR", "DPLJ"}},
    FRJU = {{"WATR", "DFJU"}},
    SOIL = {{"FRSR", "FRSL"}},
    FRSR = {{"SOIL", "FRSL"}},

    -- Acid + baking soda fizzing (products: carbon dioxide; spent acid becomes water).
    BICA = {{"ACID", "CO2G"}, {"ACET", "CO2G"}, {"CITR", "CO2G", 1, "WATER"}},
    ACID = {{"BICA", "WATR"}, {"IRON", "HYDR", 0.05}, {"STEL", "HYDR", 0.05},
            {"ZINC", "HYDR", 0.05}, {"ALUM", "HYDR", 0.05}},
    ACET = {{"BICA", "WATR"}},
    CITR = {{"BICA", "WATR", 1, "WATER"}},

    -- Displacement: a more reactive metal takes copper out of copper sulfate solution.
    CUSU = {{"IRON", "COPR", 0.1, "WATER"}, {"STEL", "COPR", 0.1, "WATER"},
            {"ZINC", "COPR", 0.1, "WATER"}},
}

-- Decay: fungus and rot spoil organic materials (the organic material turns into ROT).
local organicIdentifiers = {
    "WHEA", "CRSK", "CORN", "CROT", "MILK", "FRUT", "ALPR", "EGG", "WOOL",
    "PJUI", "FRJU", "DPLJ", "DFJU"
}
for _, identifier in ipairs(organicIdentifiers) do
    extraReactions[identifier] = extraReactions[identifier] or {}
    table.insert(extraReactions[identifier], {"FUGI", "ROT", rotChance})
    table.insert(extraReactions[identifier], {"ROT", "ROT", rotChance})
end

-- Resolve identifiers to numeric IDs once at load time.
local reactionRules = {}
for currentIdentifier, rules in pairs(extraReactions) do
    local list = {}
    for _, rule in ipairs(rules) do
        local neighbourID = customIDs[rule[1]]
        local productID = customIDs[rule[2]]
        if neighbourID and productID then
            list[#list + 1] = {
                neighbour = neighbourID,
                product = productID,
                chance = rule[3] or 1,
                requires = rule[4]
            }
        end
    end
    if #list > 0 then reactionRules[currentIdentifier] = list end
end

local function tryExtraReaction(i, x, y, identifier, found)
    local list = reactionRules[identifier]
    if not list then return false end
    found = found or collectNeighbourTypes(x, y, i)
    for _, rule in ipairs(list) do
        if found[rule.neighbour]
           and (rule.requires ~= "WATER" or hasWater(found))
           and (rule.chance >= 1 or math.random() < rule.chance) then
            sim.partChangeType(i, rule.product)
            return true
        end
    end
    return false
end

-- ============================================================
-- BEHAVIOUR HANDLERS
-- Every element gets ONE Update function that runs its handlers in order.
-- A handler returns true only if the particle was changed or removed.
-- ============================================================
local handlers = {}
local function addHandler(identifier, fn)
    if not customIDs[identifier] then return end
    handlers[identifier] = handlers[identifier] or {}
    table.insert(handlers[identifier], fn)
end

-- 1) Shared reaction rules first.
for identifier in pairs(reactionRules) do
    addHandler(identifier, function(i, x, y, found)
        return tryExtraReaction(i, x, y, identifier, found)
    end)
end

-- 2) Heated oxidation (temperatures in Kelvin).
--    Carbon burns to CO2 at about 500 C, sulfur burns to sulfur oxide at about 250 C.
local oxidation = {
    CARB = {minTemp = K(500), product = "CO2G"},
    SULF = {minTemp = K(250), product = "SUOX"}
}
for identifier, info in pairs(oxidation) do
    addHandler(identifier, function(i, x, y, found)
        local oxygenID = customIDs["OXYG"]
        local productID = customIDs[info.product]
        if not oxygenID or not productID or not found[oxygenID] then return false end
        if (sim.partProperty(i, "temp") or ROOM) < info.minTemp then return false end
        local oxygenParticle = findNeighbourIn(x, y, {[oxygenID] = true}, i)
        if oxygenParticle then sim.partKill(oxygenParticle) end
        sim.partChangeType(i, productID)
        return true
    end)
end

-- 3) Hydrogen peroxide: strong heating (150 C) -> water + one oxygen particle.
addHandler("H2O2", function(i, x, y, found)
    if (sim.partProperty(i, "temp") or ROOM) < K(150) then return false end
    local oxygenID, wID = customIDs["OXYG"], customIDs["WATR"]
    if not oxygenID or not wID then return false end
    local px, py = findEmptyNear(x, y, 2)
    if px == nil then return false end
    local created = sim.partCreate(-1, px, py, oxygenID)
    if created ~= nil and created >= 0 then
        sim.partChangeType(i, wID)
        return true
    end
    return false
end)

-- 4) Hot cooking oil sizzles: water touching oil above 100 C flashes into steam.
local function sizzle(i, x, y, found)
    if (sim.partProperty(i, "temp") or ROOM) < K(100) then return false end
    local p = findNeighbourIn(x, y, waterTypeSet, i)
    if p and vapourID then
        sim.partChangeType(p, vapourID)
    end
    return false
end
addHandler("COIL", sizzle)
addHandler("VOIL", sizzle)

-- 5) Flammable materials burn when touching native fire or spark.
local fuelIdentifiers = {
    "OIL", "DSEL", "DESL", "PETR", "VOIL", "COIL", "BITH", "ETHL", "KRSE",
    "HYDR", "METH", "ETHA", "PROP", "BUTA", "COMO", "H2SG"
}
local function igniteFuel(i, x, y, found)
    if not hasNativeFireOrSpark(found) then return false end
    sim.partChangeType(i, elements.DEFAULT_PT_FIRE)
    local px, py = findEmptyNear(x, y, 1)
    if px ~= nil then
        sim.partCreate(-1, px, py, elements.DEFAULT_PT_SMKE)
    end
    return true
end
for _, identifier in ipairs(fuelIdentifiers) do
    addHandler(identifier, igniteFuel)
end

-- 6) EXPL: fictional arcade explosive, becomes native BANG when ignited.
addHandler("EXPL", function(i, x, y, found)
    if hasNativeFireOrSpark(found) then
        sim.partChangeType(i, elements.DEFAULT_PT_BANG)
        return true
    end
    return false
end)

-- 7) Soil and fertilised soil: wet soil becomes mud, unless a seed/sprout is beside it.
local function wetSoil(i, x, y, found)
    local seedNear = found[customIDs["CRSD"]] or found[customIDs["CRSP"]]
    if found[customIDs["WATR"]] and not seedNear and customIDs["MUD"] then
        sim.partChangeType(i, customIDs["MUD"])
        return true
    end
    return false
end
addHandler("SOIL", wetSoil)
addHandler("FRSL", wetSoil)

-- 8) Seed growth: CRSD + (soil or fertilised soil) + water -> CRSP; later CRSP -> CRSK.
local function growthConditions(found)
    return (found[customIDs["SOIL"]] or found[customIDs["FRSL"]]) and found[customIDs["WATR"]]
end

addHandler("CRSD", function(i, x, y, found)
    if growthConditions(found) and customIDs["CRSP"] then
        sim.partChangeType(i, customIDs["CRSP"])
        sim.partProperty(i, "tmp", 0)
        return true
    end
    return false
end)

addHandler("CRSP", function(i, x, y, found)
    if growthConditions(found) then
        local ticks = (sim.partProperty(i, "tmp") or 0) + 1
        if ticks >= 45 and customIDs["CRSK"] then
            sim.partChangeType(i, customIDs["CRSK"])
            sim.partProperty(i, "tmp", 0)
            return true
        end
        sim.partProperty(i, "tmp", ticks)
    else
        sim.partProperty(i, "tmp", 0)
    end
    return false
end)

-- 9) Rusting: iron and steel + any custom water + oxygen -> RUML (slowly).
local function rust(i, x, y, found)
    if found[customIDs["OXYG"]] and hasWater(found) and customIDs["RUML"]
       and math.random() < 0.1 then
        sim.partChangeType(i, customIDs["RUML"])
        return true
    end
    return false
end
addHandler("IRON", rust)
addHandler("STEL", rust)

-- ============================================================
-- ANIMAL FEEDING, WANDERING AND PRODUCTS
-- ============================================================
local cowSheepFood = {}
for _, identifier in ipairs({"WHEA", "CRSK", "CRSD", "CROT", "CORN", "ALPR"}) do
    if customIDs[identifier] then cowSheepFood[customIDs[identifier]] = true end
end
local chickenFood = {}
for _, identifier in ipairs({"WHEA", "CRSD", "CORN", "FRSR"}) do
    if customIDs[identifier] then chickenFood[customIDs[identifier]] = true end
end

local function feedAnimal(i, x, y, foodSet)
    -- Food checks do not need to run on every simulation update.
    local feedTick = (sim.partProperty(i, "tmp4") or 0) + 1
    if feedTick < 5 then
        sim.partProperty(i, "tmp4", feedTick)
        return
    end
    sim.partProperty(i, "tmp4", 0)

    for dx = -1, 1 do
        for dy = -1, 1 do
            if dx ~= 0 or dy ~= 0 then
                local p = sim.partID(x + dx, y + dy)
                if p ~= nil and p >= 0 and foodSet[sim.partProperty(p, sim.FIELD_TYPE)] then
                    sim.partKill(p)
                    return
                end
            end
        end
    end
end

-- Change direction every so often; normal Powder Toy physics still applies.
local function wanderAnimal(i, x, y)
    local ticks = (sim.partProperty(i, "tmp") or 0) + 1
    if ticks >= 18 then
        ticks = 0
        local direction = (math.random(0, 1) == 0) and -1 or 1

        -- Avoid deliberately walking into a particle immediately beside the animal.
        local front = sim.partID(x + direction, y)
        if front ~= nil and front >= 0 then
            direction = -direction
            front = sim.partID(x + direction, y)
        end

        if front == nil or front < 0 then
            sim.partProperty(i, "vx", direction * 0.65)
        else
            sim.partProperty(i, "vx", 0)
        end
    end
    sim.partProperty(i, "tmp", ticks)
end

-- Each animal has its own tmp2/tmp3 timer; products appear in nearby empty space.
local function animalProduce(i, x, y, productID, minTicks, maxTicks)
    if not productID then return end
    local ticks = (sim.partProperty(i, "tmp2") or 0) + 1
    local target = sim.partProperty(i, "tmp3") or 0
    if target <= 0 then
        target = math.random(minTicks, maxTicks)
    end
    if ticks >= target then
        local px, py = findEmptyNear(x, y, 3)
        if px ~= nil then
            local created = sim.partCreate(-1, px, py, productID)
            if created ~= nil and created >= 0 then
                sim.partProperty(i, "tmp2", 0)
                sim.partProperty(i, "tmp3", 0)
                return
            end
        end
        -- No room: retry soon rather than losing the product.
        sim.partProperty(i, "tmp2", target - 1)
        sim.partProperty(i, "tmp3", target)
        return
    end
    sim.partProperty(i, "tmp2", ticks)
    sim.partProperty(i, "tmp3", target)
end

local function registerAnimal(identifier, foodSet, productIdentifier, minTicks, maxTicks)
    addHandler(identifier, function(i, x, y, found)
        feedAnimal(i, x, y, foodSet)
        animalProduce(i, x, y, customIDs[productIdentifier], minTicks, maxTicks)
        wanderAnimal(i, x, y)
        return false   -- the animal is never removed or changed by its own update
    end)
end
registerAnimal("COW", cowSheepFood, "MILK", 180, 300)
registerAnimal("SHEP", cowSheepFood, "WOOL", 220, 360)
registerAnimal("CHKN", chickenFood, "EGG", 160, 280)

-- ============================================================
-- INSTALL ONE COMBINED UPDATE FUNCTION PER ELEMENT
-- ============================================================
for identifier, list in pairs(handlers) do
    local elementID = customIDs[identifier]
    if elementID then
        elements.property(elementID, "Update", function(i, x, y, surround_space, nt)
            local found = collectNeighbourTypes(x, y, i)
            for k = 1, #list do
                if list[k](i, x, y, found) then return true end
            end
            return false
        end)
    end
end

-- ============================================================
-- SQUEEZER TOOL (not a physical particle)
-- Requires a Powder Toy build exposing a Lua tools API (tools.allocate / tools.property).
-- FRUT -> FRJU; CRSK/ALPR/WHEA -> PJUI; COW/SHEP -> MILK; MUD -> WATR.
-- ============================================================
local function squeezerPerform(i, x, y, strength, brushX, brushY)
    if i == nil or i < 0 then return false end
    local sourceType = sim.partProperty(i, sim.FIELD_TYPE)
    local productID = nil
    local consumeSource = false

    if customIDs["FRUT"] and sourceType == customIDs["FRUT"] then
        productID = customIDs["FRJU"]
        consumeSource = true
    elseif (customIDs["CRSK"] and sourceType == customIDs["CRSK"]) or
           (customIDs["ALPR"] and sourceType == customIDs["ALPR"]) or
           (customIDs["WHEA"] and sourceType == customIDs["WHEA"]) then
        productID = customIDs["PJUI"]
        consumeSource = true
    elseif (customIDs["COW"] and sourceType == customIDs["COW"]) or
           (customIDs["SHEP"] and sourceType == customIDs["SHEP"]) then
        productID = customIDs["MILK"]
    elseif customIDs["MUD"] and sourceType == customIDs["MUD"] then
        productID = customIDs["WATR"]
        consumeSource = true
    end

    if not productID then return false end

    if consumeSource then
        -- Replace the squeezed particle with its product in the same spot.
        sim.partKill(i)
        local created = sim.partCreate(-1, x, y, productID)
        return created ~= nil and created >= 0
    end

    local px, py = findEmptyNear(x, y, 3)
    if px == nil then return false end
    local created = sim.partCreate(-1, px, py, productID)
    return created ~= nil and created >= 0
end

if tools and tools.allocate and tools.property then
    local toolIdentifier = GROUP .. "_TOOL_SQUEEZER"
    local squeezerIndex = tools.index and tools.index[toolIdentifier]
    if squeezerIndex == nil then
        squeezerIndex = tools.allocate(GROUP, "SQUEEZER")
    end
    if squeezerIndex and squeezerIndex >= 0 then
        tools.property(squeezerIndex, "Name", "Squeezer")
        tools.property(squeezerIndex, "Description", "Extract fruit juice, plant juice, water from mud, or milk from a cow/sheep. Select the tool and click the source material.")
        tools.property(squeezerIndex, "Colour", 0x3976D2)
        tools.property(squeezerIndex, "MenuSection", elem.SC_TOOL)
        tools.property(squeezerIndex, "Perform", squeezerPerform)
        print("Mackelements: Squeezer tool registered.")
    else
        print("Mackelements: failed to register Squeezer tool.")
    end
else
    print("Mackelements: this Powder Toy build does not expose the Lua tools API; Squeezer tool was not registered.")
end

print("Mackelements loaded: " .. registeredCount .. " of " .. #data .. " element definitions.")
print("Mackelements: v11.26 UPGRADE loaded (real-life reactions, phase changes, crops, animals, fuels, and Squeezer).")
