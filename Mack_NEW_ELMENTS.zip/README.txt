This is a lua script mod for TPT/the powder toy.
This is still in development stage.

Ask permission from the developer to post it online on different websites/places.
Why:
1.People might think you are the developer who developed this mod
2.This is posted on GitHub
3.You cannot just move this

Details:
1.Juice,solids,powders,liquids,gases,biology,science,physics,and chemistry are included in here
2.A total of 97 elements
3.A total of 1 tools
4.Total of new things added for this lua script mod:98

Warning:This lua script mod is for the PowderToy,not for other programmes/applications.

Things to know about this:
People/bots who helped to make this
1.ChatGPT(Coder/Assistant)
2.Mackeria(Designer/founder)

How to use this mod for the powder toy:
1.Open the folder
2.Get the note pad 
3.Put the note pad into you scripts folder
4.Open PowderToy
5.Go to script manager
6.Enable the script
7.Play it

This is posted on github and the official PowderToy forum. 